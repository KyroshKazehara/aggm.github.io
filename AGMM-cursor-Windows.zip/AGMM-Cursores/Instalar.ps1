﻿param([switch]$Restaurar)
$ErrorActionPreference='Stop'
$destination=Join-Path $env:LOCALAPPDATA 'AGMM\Cursores'
$backup=Join-Path $destination 'esquema-anterior.json'
$regPath='HKCU:\Control Panel\Cursors'
$slots=@('Arrow','Help','AppStarting','Wait','Crosshair','IBeam','NWPen','No','SizeNS','SizeWE','SizeNWSE','SizeNESW','SizeAll','UpArrow','Hand','Pin','Person')
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class AGMMCursorRefresh { [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint a,uint b,IntPtr c,uint d); }'
if($Restaurar){
 if(!(Test-Path -LiteralPath $backup)){throw 'Nenhum esquema anterior salvo por este instalador.'}
 $saved=Get-Content -LiteralPath $backup -Raw | ConvertFrom-Json
 foreach($slot in $slots){if($saved.values.PSObject.Properties.Name -contains $slot){New-ItemProperty -Path $regPath -Name $slot -Value ([string]$saved.values.$slot) -PropertyType ExpandString -Force | Out-Null}else{Remove-ItemProperty -Path $regPath -Name $slot -ErrorAction SilentlyContinue}}
 Set-Item -Path $regPath -Value ([string]$saved.name)
}else{
 $map=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'cursores.json') -Raw | ConvertFrom-Json
 foreach($slot in $slots){$name=[string]$map.$slot;if([IO.Path]::GetFileName($name) -ne $name -or !$name.EndsWith('.ani')){throw 'Nome de cursor invalido.'};if(!(Test-Path -LiteralPath (Join-Path $PSScriptRoot $name))){throw "Cursor ausente: $name"}}
 New-Item -ItemType Directory -Path $destination -Force | Out-Null
 if(!(Test-Path -LiteralPath $backup)){
  $key=Get-Item -Path $regPath;$values=@{};foreach($slot in $slots){if($key.GetValueNames() -contains $slot){$values[$slot]=$key.GetValue($slot,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}}
  @{name=$key.GetValue('');values=$values} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $backup -Encoding UTF8
 }
 $paths=@();foreach($slot in $slots){$name=[string]$map.$slot;$target=Join-Path $destination $name;Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $target -Force;New-ItemProperty -Path $regPath -Name $slot -Value $target -PropertyType ExpandString -Force | Out-Null;$paths+=$target}
 Set-Item -Path $regPath -Value 'AGMM - Tripulante branco'
 New-Item -Path ($regPath+'\Schemes') -Force | Out-Null
 New-ItemProperty -Path ($regPath+'\Schemes') -Name 'AGMM - Tripulante branco' -Value ($paths -join ',') -PropertyType String -Force | Out-Null
}
if(![AGMMCursorRefresh]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,3)){throw 'Configuracao salva. Abra as configuracoes de mouse para aplicar o esquema.'}
Write-Host $(if($Restaurar){'Esquema anterior restaurado.'}else{'Cursores AGMM instalados e aplicados somente nesta conta.'})
