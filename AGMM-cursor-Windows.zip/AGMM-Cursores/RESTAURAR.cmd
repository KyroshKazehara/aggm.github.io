@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar.ps1" -Restaurar
if errorlevel 1 echo Nao foi possivel concluir. Confira a mensagem acima.
pause
